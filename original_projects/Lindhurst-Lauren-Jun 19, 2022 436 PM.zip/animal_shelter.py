from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, pwd):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:40690/aac' % (user, pwd))
        # where 40690 is your unique port number
        self.database = self.client['aac']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            if data:
                self.database.animals.insert_one(data)  # data should be dictionary
                return True
        else:
            raise Exception ("Nothing to save, because data parameter is empty")
            return False
        
# Create method to implement the R in CRUD.
    def read(self, search):
        # Checks to see if the data is null or empty and returns exception in either case
        if search is not None:
            if search:
                return self.database.animals.find(search, {"_id":False})
        else:
            raise Exception("Nothing to search, because data parameter is empty")
            
# The method to implement the U in CRUD.
    def update(self, data, newData):
        if data:
            results = self.database.animals.find_one(data, newData)
            if results is not None:
                changeData = self.database.animals.update_one(data, {'$set' : newData})
                print("Successfully Updated to: ")
                return newData
            else:
                changeData = self.database.animals.insert_one(newData)
                print("Successfully Added: ")
                return changeData
        else:
            results = self.database.animals.find_one({}, {"_id": False, "name":1, "type":1})
            raise Exception("Nothing to update, because data parameter is empty")
            
# The method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            return self.database.animals.delete_one(data)
            
        else:
            raise Exception("Nothing to delete, because remove parameter is empty")