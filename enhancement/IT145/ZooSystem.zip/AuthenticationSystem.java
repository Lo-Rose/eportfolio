/* 
 * @program Zoo Authentication System
 * @class AuthenticationSystem.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;

// Import libraries
import java.io.Console;
import java.io.File;
import java.io.FileNotFoundException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/*
 * This is the class for the Zoo's Authentication System.
 * This class reads the credentials text file in
 * and validates the users input with the data store in the file.
 */
public class AuthenticationSystem {

    /*
     * Method to authenticate user
     */
    public static boolean userCredentials(String user, String path) throws FileNotFoundException, Exception {
        Scanner scnr = new Scanner(System.in); // init scanner for input
        String userPass;
        String userRole;
        boolean exit;

        // reads in the user credential text file
        File file = new File(path + "credentials.txt");
        Scanner fileContent = new Scanner(file);

        while (fileContent.hasNextLine()) { // stop while loop at final line
            String line = fileContent.nextLine(); // iterate each line on file
            String[] s = line.split("\\s+"); // split line content as array on whitespaces

            if (s[0].equals(user)) {
                int i;
                for (i = 0; i < 3; ++i) { // if password is enter incorrectly 3 times loop
                    if (path.contains("src")) {
                        System.out.print("\nEnter password: "); // Prompt for password
                        userPass = scnr.nextLine(); // Store next line into variable userPass
                    } else {
                        Console console = System.console();
                        char[] pass = console.readPassword("\nEnter Password: ", "*"); // hide password if on console or shell
                        userPass = String.valueOf(pass); // Store input into variable userPass
                    }
                    
                    String encrypPass = MD5Digest(userPass); // call digest class method
                    
                    if (s[1].equals(encrypPass)) {
                        userRole =  s[s.length-1];
                        exit = Roles.Dashboard(userRole, user, path); // call roles class method
                        return exit;
                    } else if (i == 2) {
                        Display.clearScreen();
                        String message = "Maximum attempts reached. Exiting Program.."; // if entered 3 times incorrectly print to screen
                        Display.showDialog(message); // call display dialog box
                        return true;
                    } else {
                        System.out.printf("\n\033[1;33;41m ERROR: Incorrect password. (%d) \033[0m\n", i + 1); // If entered incorrectly
                    }
                }
            }
        }
        return false;
    }
    
     /*
      * Method to digest user password (MD5 Digest)
      */
    private static String MD5Digest(String userPass) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(userPass.getBytes());
        byte[] digest = md.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
        }

        String digestPass = sb.toString();

        return digestPass;
    }
}