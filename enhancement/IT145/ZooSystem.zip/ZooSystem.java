/* 
 * @program Zoo Authentication System
 * @class ZooSystem.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;


// Import libraries
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/*
 * This is the main class.
 * This program authenticates users ensuring only appropriate people gain access to the data.
 * This is called authentication. Once the user has gained entry, the data displayed
 * is related to their assigned role in the zoo system. This is called authorization. 
 * This system authenticates and authorizes a user, displays animal monitoring, displays habitat
 * monitoring, and displays user information based on verified role.
 */
public class ZooSystem {

  /*
   * Main method
   */
  public static void main(String[] args) throws IOException, InterruptedException, Exception {
    Scanner scnr = new Scanner(System.in); // input init scanner
    String dirPath = null;
    boolean exit = false;

    // verify text files are found
    File dir = new File("txt_files/");
    if (!dir.exists()) {
      dirPath = "src/txt_files/"; 
    } else {
      System.out.println("Information not found!"); // if not display error message
    }

    Display.clearScreen(); // call display clear screen

    System.out.println("[LOGIN]\n"); // Display login under main header

    // obtain user name or exit program
    while (!exit) {
      System.out.print("Enter user name: ");
      String userName = scnr.nextLine().toLowerCase();

      if ("x".equals(userName)) { // then exit
        exit = true;
      } else { // if not save entered username to variable user
        String user = userName;

        exit = AuthenticationSystem.userCredentials(user, dirPath); // call AuthenticationSystem class method

        if (!exit) { // If user name is not found display error
          System.out.println("\n\033[1;33;41m ERROR: User " + user.toUpperCase() + " not found. \033[0m\n");
        }
      }
    }
    System.out.println( //after system exit display program terminated
        "\n\033[1;33;42m " + Display.strRepeat("*", 5) + " [Program Terminated] " + Display.strRepeat("*", 5) + " \033[0m\n");

    // close scanner 
    scnr.close();
    
    // system exit
    System.exit(0);
  }
}