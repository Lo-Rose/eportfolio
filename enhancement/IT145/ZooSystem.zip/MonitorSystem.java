/* 
 * @program Zoo Authentication System
 * @class MonitorSystem.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/*
 * This is the monitoring system class. This class creates and displays an
 * animal information dashboard and habitat information dashboard based on the
 * role of the user. Admins & Zookeepers are able to see both dashboards, Veterinarians
 * are able to see only the Animals Dashboard. The information is found in the appropriate
 * section of the animals text file and/or habitats text file.
 */
public class MonitorSystem {

    /*
     * Method to display Animal and Habitat dashboard to user.
     */
    public static boolean Dashboard(String userRole, String user, String path, String monitor) throws FileNotFoundException, Exception {
        Scanner scnr = new Scanner(System.in); // init scanner for input
        String fname;
        char i = 64;
        char select = 0;
        String detailOf;
        boolean exit = false;
        
        // defines animals or habitats monitoring 
        if ("animals".equals(monitor)) {
            fname = "animals.txt";
        } else {
            fname = "habitats.txt";
        }
        
        // While selection is not x display monitoring dashboard and current logged in user
        while (select != 'x') {
            Display.showCurrentUser(user, userRole); // display current user

            System.out.println("[" + monitor.toUpperCase() + " MONITORING DASHBOARD]\n"); // Display Animal or Habitat Monitoring Dashboard

            // open text file
            File file = new File(path + fname);
            Scanner fileContent = new Scanner(file);

             // read file content
            while (fileContent.hasNextLine()) { 
                String line = fileContent.nextLine();

                if (line.contains("Details")) { // If read line contains details print 
                    i += 1;
                    System.out.println("[" + i + "] " + line);
                }
            }

            System.out.println("\n[x] Return to Main Dashboard");  // Display option to return to main dashboard

            // Enter option to monitor
            System.out.printf("\n\nENTER %s TO MONITOR: ", fname.substring(0, fname.length() - 5).toUpperCase()); 
            select = scnr.next().charAt(0); // entered option is store in variable select
            
            switch (select) {  // Case statement - if select is
                case 'x':  // x- exit and show main dashboard
                    exit = Roles.Dashboard(userRole, user, path);
                    break; // break
                case 'X': // X- exit and show main dashboard
                    exit = Roles.Dashboard(userRole, user, path);
                    break; // break
                case 'A': // A - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Lion";  // details for lion if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    } else { // else 
                        detailOf = "Habitat - Penguin"; // Details from Penguin if from Habitat Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    }
                    break; // break
                case 'a': // a - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Lion"; // details for lion if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    } else {
                        detailOf = "Habitat - Penguin"; // Details from Penguin if from Habitat Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    }
                    break; // break
                case 'B': // B - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Tiger"; // details for tiger if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    } else { 
                        detailOf = "Habitat - Birds"; // details for bird if habitats Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    }
                    break; // break
                case 'b': // b - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Tiger"; // details for tiger if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path);
                    } else {
                        detailOf = "Habitat - Birds"; // details for birds if habitat Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    }
                    break;    // break
                case 'C': // C - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Bear"; // details for bear if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showinfo to display info
                    } else {
                        detailOf = "Habitat - Aquarium"; // details for aquarium if habitats Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // calls showInfo to display info
                    }
                    break; // break
                case 'c': // c - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Bear"; // details for bear if animals dashboard
                        showInfo(fname, detailOf, user, userRole, path); // call showInfo to display info
                    } else {
                        detailOf = "Habitat - Aquarium"; // details for aquarium if habitats Dashboard
                        showInfo(fname, detailOf, user, userRole, path);
                    }
                    break; // break
                case 'D': // D - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Giraffe"; // details for giraffe if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // call showInfo to display info
                    }
                    break; // break
                case 'd': // d - displays details from animal or habitat text file
                    if (fname.equals("animals.txt")) { // gets details from animals.txt
                        detailOf = "Animal - Giraffe"; // details for giraffe if Animals Dashboard
                        showInfo(fname, detailOf, user, userRole, path); // call showInfo to display info
                    }
                    break; // break
            }
            i = 64;
        }
        return exit;
    }
    
    /*
     * Method to display information and details of
     */
    private static void showInfo(String fname, String detailOf, String user, String userRole, String path) throws FileNotFoundException, IOException, InterruptedException {
        Display.showCurrentUser(user, userRole); // display current user
        
        String separator = "*" + Display.strRepeat("-", 54) + "*"; // Print dashboard
        
        System.out.println(separator);
        System.out.printf("| Details for: %-39s |\n", detailOf);  // display deails for and detailof info
        
        // open file
        File file = new File(path + fname);
        Scanner fileContent = new Scanner(file);

        // read file content
        while (fileContent.hasNextLine()) {
            String line = fileContent.nextLine(); //store nextline in line variable
            if (line.equals(detailOf)){  // if info equals detailof
                while (!line.equals("")) { // while line is not equal to ""
                    line = fileContent.nextLine(); // store next line in line
                    if (line.equals("") || !fileContent.hasNextLine()) { // if line equals "" or if file content has not next line
                        break; // break
                    } else { // else
                        String[] s = line.split(": "); // split line content as array
                        System.out.println(separator);
                        if (line.contains("*****")) { // if line contains *****
                            String message = s[0].substring(5) + ": " + s[1]; // start index at 5 (this avoids printing *'s from file)
                            Display.showDialog(message); // call display dialog box method
                            System.out.printf("|\033[1;33;41m %-18s \033[0m|\033[1;33;41m %-31s \033[0m|\n", s[0].substring(5), s[1]); // print
                        } else { 
                            System.out.printf("| %-18s | %-31s |\n", s[0], s[1]);
                        }
                    }
               }
            }
        }
        System.out.println(separator);
        System.out.print("\n\nPress ENTER to return to Dashboard...");
        System.in.read(); // wait user press enter key
    }
}