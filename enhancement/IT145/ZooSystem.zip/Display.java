/* 
 * @program Zoo Authentication System
 * @class Display.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;


// Import libraries
import java.awt.Toolkit;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/*
 * This is the display class. This class handles the main header of the program,
 * current user header, warning dialog box for monitoring systems,and menu options
 * based on user roles.
 */
public class Display {
    
    /*
     * Method to clear screen and print main header
     */
    public static void clearScreen() throws IOException, InterruptedException {
        
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor(); // clear shell screen in windows  
        
        // display screen header
        String tb = "\033[1;33;44m" + strRepeat("*", 73) + "\033[0m";  // print the *'s
        String spcr = "\033[1;33;44m*" + strRepeat(" ", 71) + "*\033[0m"; // print the spaces
        
        System.out.println("\n" + tb + "\n" + spcr);
        System.out.println("\033[1;33;44m*" + strRepeat(" ", 25) + "Zoo Monitoring System" + strRepeat(" ", 25) + "*\033[0m");
        System.out.println(spcr + "\n" + tb + "\n");
    }

    /*
     * Method to repeat string
     */
    public static String strRepeat(String str, int times) {
        return new String(new char[times]).replace("\0", str);
    }
    
    /*
     * Method to display current logged in user
     */
    public static void showCurrentUser(String userName, String userRole) throws IOException, InterruptedException {
        String currentUser = "|\033[1;37;45m Logged in as: " + userName + "  |  User Role: " + userRole + " \033[0m|"; // message to store in currentUser variable
        String separator = "*" + strRepeat("-", (currentUser.length() - 16)) + "*";

        clearScreen(); // clear screen
        System.out.println(separator + "\n" + currentUser + "\n" + separator + "\n"); // print currentUser stored information
    }
    
    /*
     * Method to display warning dialog box to user with sound
     */
    public static void showDialog(String message) throws IOException { 
        final Runnable sound = (Runnable)Toolkit.getDefaultToolkit().getDesktopProperty("win.sound.default"); // default windows sound store in sound
        sound.run(); // play sound
        // construct and display dialog box
        JOptionPane pane = new JOptionPane(message, JOptionPane.WARNING_MESSAGE);  // JOptionPane pane for windows dialog box
        JDialog dialog = pane.createDialog("Monitor System Alert!");  // title box Monitor System Alert!
        dialog.setAlwaysOnTop(true); // display dialog box on top
        dialog.setVisible(true); // make box visble
        dialog.setDefaultCloseOperation(JOptionPane.OK_OPTION);  // Ok closes dialog box
    }
    
    /*
     * Method to display main menu for user
     */
    public static boolean menu(String userRole, String user, String path) throws Exception {
        Scanner scnr = new Scanner(System.in); // init scanner input
        String monitor; // declare monitor variable with string type
        boolean exit = false;  // init exit boolean false
        
        // display main menu per role
        String menuOptions = "[x] Log out";  // x to log displayed
        
        switch (userRole) { // Case Statement 
            case "veterinarian": // if veterinarian is equal to userRole
                menuOptions += "  [1] Monitor Animal";  // Give menu options menu animals // option 1 only
                break; // break
            case "zookeeper": // if zookeeper is equal to userRole
                menuOptions += "  [1] Monitor Animal  [2] Monitor Habitat";  // give menu options animal and habitat  // options 1 and 2
                break; // break
            default: // for all other userRoles (admin) (default) // display 1, 2, and 3 user management.
                menuOptions += "  [1] Monitor Animal  [2] Monitor Habitat  [3]User Management";
                break; // break
        }
        
        // main menu option selection
        while (!exit) { 
            System.out.print(strRepeat("\n", 3)); // print three new lines
            System.out.println("[Main Menu]" + strRepeat("-", (menuOptions.length() - 11))); // print main menu bar --
            System.out.println(menuOptions); // Print menu options
            
            int option = scnr.next().charAt(0); // store selection in option
            
            switch (option) { // Case statement
                case '1': // if 1 is entered for option
                    monitor = "animals"; // display animal monitoring system
                    exit = MonitorSystem.Dashboard(userRole, user, path, monitor);
                    break; // break
                case '2': // if 2 is entered for option
                    monitor = "habitats"; // display habitats monitoring system
                    exit = MonitorSystem.Dashboard(userRole, user, path, monitor);
                    break; // break
                case '3': // if 3 is entered for option
                    UserModule.userManagement(userRole, user, path); // display user management dashboard from usermodule
                    break; // break
                case 'x': // if x is entered for option
                    clearScreen(); // clear screen
                    String message = "Logged out Successfully"; // Display Logged out Successfully
                    showDialog(message); // call dialog box
                    exit = true; // exit
                    break; // break
                default: // default - display main dashboard
                    exit = Roles.Dashboard(userRole, user, path);
            }
        }
        return exit;
    }
}