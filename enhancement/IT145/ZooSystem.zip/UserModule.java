/* 
 * @program Zoo Authentication System
 * @class UserModule.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/*
 * This is the user module class. This class displays the current user (admin only)
 * and the user management dashboard. The dashboard displays to the admin the 
 * usernames and roles currently in the system and what they have access to view.
 */
public class UserModule {
    
    /*
     * Method to display user name and user managment dashboard
     */
    public static void userManagement(String userRole, String user, String path) throws FileNotFoundException, IOException, InterruptedException {
        String a = null; // declaring a string
        String h = null; // declaring h string
        String u = null; // declaring u string
        
        Display.showCurrentUser(user, userRole); // display current user and role
        
        System.out.println("[USER MANAGEMENT DASHBOARD]"); // display dashboard header
        
        // read user manage text file
        File file = new File(path + "usermanage.txt");
        Scanner fileContent = new Scanner(file);
        
        // create and display user management dashboard
        System.out.println(Display.strRepeat(" ", 42) + "*" + Display.strRepeat("-", 28) + "*");
        System.out.printf(Display.strRepeat(" ", 42) + "|      %-21s |\n", "DASHBOARD ACCESS");
        System.out.println(Display.strRepeat(" ", 5) + "*" + Display.strRepeat("-", 65) + "*");
        System.out.printf(Display.strRepeat(" ", 5) + "| %-18s | %-13s | %7s | %8s | %5s |\n", "Username", "Role", "Animals", "Habitats", "Users");

        int i = 1;
        while (fileContent.hasNextLine()) { // while file content has next line
            String line = fileContent.nextLine(); // store each next line in line
            String[] s = line.split(" "); // split line variable content as array
            
            switch (s[s.length - 1]) {  // Case Statement
                case "zookeeper": // if zookeeper
                    a = "X"; // give x to animals dashboard access
                    h = "X"; // give x to habitats dashboard access
                    u = ""; // leave blank
                    break; // break
                case "veterinarian": // if veterinarian
                    a = "X"; // give x to animals dashboard access
                    h = ""; // leave blank
                    u = ""; // leave blank
                    break; // break
                case "admin": // if admin
                    a = "X"; // give x to animals dashboard access
                    h = "X"; // give x to habitats dashboard access
                    u = "X"; // give x to users dashboard access
                    break; // break
            }
            System.out.println("*" + Display.strRepeat("-", 70) + "*"); // print - and * for dashboard
            System.out.printf("| %2d | %-18s | %-13s |    %-4s |     %-4s |   %-3s |\n", i, s[0], s[s.length - 1], a, h, u); // print dashboard menu line
            ++i;
        }
        System.out.println("*" + Display.strRepeat("-", 70) + "*"); // print rest of dashboard menu
    }
}