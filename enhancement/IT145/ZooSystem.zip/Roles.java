/* 
 * @program Zoo Authentication System
 * @class Roles.java
 * @author Lauren Lindhurst
 * @school SNHU
 * @course IT-145
*/

// java package
package zoo;

// Import libraries
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * This is the Roles class. This class reads in the user role text file and
 * displays the users role and role description to the user in the main dashboard.
 * It also displays the menu options to use in the system.
 */
public class Roles {

    /*
     * Method to display user role info and dashboard.
     */
    public static boolean Dashboard(String userRole, String user, String path) throws IOException, InterruptedException, Exception {
        String line;
        boolean exit;

        Display.showCurrentUser(user, userRole); // display current user and role
        
        System.out.println("[MAIN DASHBOARD]\n"); // display Main dashboard header

        // open user role file
        File file = new File(path + userRole + ".txt"); // depending on user role
        Scanner fileContent = new Scanner(file);

        // read file content
        while (fileContent.hasNextLine()) { // while file content has next line
            line = fileContent.nextLine(); // store next line in line
            
            String[] sentence = wrapLine(line, 70); // call wrap method
            
            for (int i = 0; i < sentence.length; ++i) {  // for loop to print description
                System.out.println(sentence[i]);
            }
        }

        exit = Display.menu(userRole, user, path);
        
        return exit;
    }
    
    /*
     * This method takes a string value and a line length, and returns
     * an array of lines.
     */
    public static String[] wrapLine(String text, int desc) {
        // return empty array for null text
        if (text == null)
            return new String[] {};

        // return text if desc is zero or less
        if (desc <= 0)
            return new String[] {text};

        // return text if less than length
        if (text.length() <= desc)
            return new String[] {text};

        char[] chars = text.toCharArray();
        ArrayList<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        StringBuilder word = new StringBuilder();

        for (int i = 0; i < chars.length; i++) {
            word.append(chars[i]);

            if (chars[i] == ' ') {
                if ((line.length() + word.length()) > desc) {
                    lines.add(line.toString());
                    line.delete(0, line.length());
                }

                line.append(word);
                word.delete(0, word.length());
            }
        }

        // handle any extra chars in current word
        if (word.length() > 0) {
            if ((line.length() + word.length()) > desc) {
              lines.add(line.toString());
              line.delete(0, line.length());
            }
            line.append(word);
        }

        // handle extra line
        if (line.length() > 0) {
            lines.add(line.toString());
        }

        String[] ret = new String[lines.size()];
        for (int c = 0; c < lines.size(); ++c) {
            ret[c] = (String) lines.get(c);
        }
        
        return ret;
    }
}