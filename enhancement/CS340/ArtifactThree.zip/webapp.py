from jupyter_plotly_dash import JupyterDash

import dash
import dash_leaflet as dl
from dash import dcc
from dash import html, DiskcacheManager
import plotly.express as px
from dash import dash_table as dt
import base64 # Image encoder
from dash.dependencies import Input, Output, State
from bson.json_util import dumps

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pymongo import MongoClient
import uuid


#### FIX ME (COMPLETED) #####
# change animal_shelter and AnimalShelter to match your CRUD Python module file name and class name
from animal_shelter import AnimalShelter

# Using Python UUID to create unique id based on host address and current time
#uuidOne = uuid.uuid1() #Removed for cosmetic purposes for Capstone



###########################
# Data Manipulation / Model
###########################
# FIX ME (COMPLETED): update with your username and password and CRUD Python module name

user = "aacuser"
pwd = "puppy"
a = AnimalShelter(user, pwd)


# class read method must support return of cursor object and accept projection json input
df = pd.DataFrame.from_records(a.read({}))



#########################
# Dashboard Layout / View
#########################

# For testing in jupyter notebook
#app = JupyterDash('Salvare Search for Rescue Web App')

# For testing in computer terimanl
app = dash.Dash('Salvare Search for Rescue Web App')

#FIX ME (COMPLETED): Add in Grazioso Salvare’s logo
image_filename = 'Grazioso_Salvare_Logo.png' 
encoded_image = base64.b64encode(open(image_filename, 'rb').read())

#FIX ME (COMPLETED): Place the HTML image tag in the line below into the app.layout code according to your design
#FIX ME (COMPLETED): Also remember to include a unique identifier such as your name or date

app.layout = html.Div([
    html.Div(id='hidden-div', style={'display':'none'}),
    html.Center(html.Img(src='data:image/png;base64,{}'.format(encoded_image.decode()), style={'width':225})),
    html.Center(html.B(html.H1('Grazioso Salvare Animal Shelter Web Application Dashboard'))),
    html.Center(html.B(html.H2('Lauren Lindhurst - SNHU CS-340', style={'color': 'purple'}))),
    html.Hr(),
    html.Div(          
            #Radio items to select different rescue filter options
        dcc.RadioItems(
            id = 'filter-type',
            # labels and keys based on requirements
            options = [
                {'label': 'Water Rescue', 'value': 'WR'},
                {'label': 'Mountain/Wilderness Rescue', 'value': 'MWR'},
                {'label': 'Disaster Rescue/Individual Tracking', 'value': 'DRIT'},
                {'label': 'Reset- returns to unfiltered state', 'value': 'RESET'}
                ],
                value = 'RESET',
                labelStyle={'display': 'inline-block'}
                )
            ),
            html.Hr(),
            dt.DataTable(
                id='datatable-id',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": True}
                    for i in df.columns
                ],
                data=df.to_dict('records'),
                editable = False,
                filter_action = "native",
                #sort_action = "native",
                sort_mode = "multi",
                column_selectable = False,
                row_selectable = "single",
                row_deletable = False,
                selected_columns=[],
                selected_rows=[],
                page_action="native",
                page_current= 0,
                page_size= 10,
            ),
        # FIX ME (COMPLETED): Set up the features for your interactive data table to make it user-friendly for your client
        html.Br(),
        html.Hr(),
        # This sets up the dashboard so that your chart and your geolocation chart are side-by-side
        html.Div(className='row',style={'display' : 'flex'},children=[html.Div(id='graph-id',className='col s12 m6',),html.Div(id='map-id',className='col s12 m6',)]),

    # ADDED FOOTER
        html.Div([
            html.Hr(),
            html.P([
                "Module 7-2 Project Two Submission",
                html.Br(),
                "CS-340 Client/Server Development - 22EW5 - Southern New Hampshire University",
                html.Br(),
                "June 2022" ],
                style={'fontSize' : 12})
            ])
        ])
#############################################
# Interaction Between Components / Controller
#############################################

@app.callback([Output('datatable-id','data'),
               Output('datatable-id','columns')],
              [Input('filter-type', 'value')])

def update_dashboard(filter_type):
### Code to filter interactive data table with MongoDB queries
# Adjusts the request for specific dog types for Water Rescue
    if filter_type == "WR":
        df = pd.DataFrame(list(a.read(
            {'$and': [{'sex_upon_outcome': 'Intact Female'},
            {'$or': [{'breed': 'Labrador Retriever Mix'},
                     {'breed': 'Chesa Bay Retr Mix'},
                     {'breed': 'Newfoundland Mix'},
                     {'breed': 'Newfoundland/Labrador Retriever'},
                     {'breed': 'Newfoundland/Australian Cattle Dog'},
                     {"breed": "Newfoundland/Great Pyrenees"}
                     ]},
                      {'$and': [{'age_upon_outcome_in_weeks': {'$gte': 26}},
                                {'age_upon_outcome_in_weeks': {'$lte': 156}}
                                ]
                       }]
             })))
    # Adjusts the request for specific dog types for Mountain/Wilderness
    elif filter_type == 'MWR':
        df = pd.DataFrame(list(a.read(
            {'$and': [{'sex_upon_outcome': 'Intact Male'},
            {'$or': [{'breed': 'German Shepherd'},
                     {'breed': 'Alaskan Malamute'},
                     {'breed': 'Old English Sheepdog'},
                     {'breed': 'Rottweiler'},
                     {'breed': 'Siberian Husky'}]
             },
                      {'$and': [{'age_upon_outcome_in_weeks': {'$gte': 26}},
                                {'age_upon_outcome_in_weeks': {'$lte': 156}}]
                       }]
             })))
    # Adjusts the request for specific dog types for Disaster Rescue..
    elif filter_type == 'DRIT':
        df = pd.DataFrame(list(a.read(
            {'$and': [{'sex_upon_outcome': 'Intact Male'},
            {'$or': [{'breed': 'Doberman Pinscher'},
                     {'breed': 'German Sheperd'},
                     {'breed': 'Golden Retriever'},
                     {'breed': 'Bloodhound'},
                     {'breed': 'Rottweiler'}]
             },
                      {'$and': [{'age_upon_outcome_in_weeks': {'$gte': 20}},
                                {'age_upon_outcome_in_weeks': {'$lte': 300}}]
                       }]
             })))
    # Resets search to unfiltered to show all results
    elif filter_type == 'RESET':
        df = pd.DataFrame.from_records(a.read({}))
        #df = pd.DataFrame.from_records(myQuery)
        
    columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns]
    data=df.to_dict('records')
        
    return (data,columns)
        
        

#This callback will highlight a row on the data table when the user selects it
@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    [Input('datatable-id', 'selected_columns')]
    )
def update_styles(selected_columns):
    return [{'if':{'column_id':i},'background_color':'#D2F3FF'} for i in selected_columns]

# Function to update pie chart
@app.callback(
    Output('graph-id', "children"),
    [Input('datatable-id', "derived_viewport_data")]
    )
def update_graphs(viewData):
    ### FIX ME (COMPLETED) ####
    # imports the currently displayed data
    dff = pd.DataFrame.from_dict(viewData)
    #creates values for breed displayed in the pie chart
    names = dff['breed'].value_counts().keys().tolist()
    values = dff['breed'].value_counts().tolist()
    #returns a pie chart from the data above
    return [
        dcc.Graph(
            figure = px.pie(
                data_frame=dff,
                values = values, 
                names = names, 
                color_discrete_sequence=px.colors.sequential.RdBu,
                width=800, 
                height=500
            )
        )
    ]

@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_viewport_data"),
     Input('datatable-id', 'selected_rows'),
     Input('datatable-id', 'selected_columns')]
    )
def update_map(viewData, selected_rows, selected_columns):
# FIX ME (COMPLETED): Add in the code for your geolocation chart
#If you completed the Module Six Assignment, you can copy in the code you created here.
    # imports the currently viewed data
    dff = pd.DataFrame.from_dict(viewData)
    #determines the default status
    if selected_columns is not None:
        column = selected_columns#['column']
    else:
        column = selected_rows[0]

        lat = dff.loc[column,'location_lat']
        long = dff.loc[column, 'location_long']
        name = dff.loc[column, 'name']
        breed = dff.loc[column, 'breed']
        animal = dff.loc[column, 'animal_type']
        age = dff.loc[column, 'age_upon_outcome']

    if name == "":
        name = "No Name"
    # creates a map for a single selected row or the default
        return [
            dl.Map(style={'width':'1000px', 'height': '500px'},
                   center=[30.75,-97.48], zoom=10,
                   children=[
                       dl.TileLayer(id="base-layer-id"),
                       # marker with tool tip and popup
                       dl.Marker(
                           position=[lat,long],
                           children=[
                               dl.Tooltip("({:.3f}, {:.3f})".format(lat,long)),
                               dl.Popup([
                                   html.H2(name),
                                   html.P([
                                       html.Strong("{} | Age: {}".format(animal,age)),
                                       html.Br(),
                                       breed])
                                   ])
                               ])
                       ])
            ]

#################
# APP Execution #
#################
# For testing in jupyter notebook        
#app

# For testing in computer terminal
if __name__ == '__main__':
   app.run_server()
