from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, pwd):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:27017/aac' % (user, pwd))
        # where 40690 is your unique port number
        self.database = self.client['aac']
        self.collection = self.database['animals']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
                self.collection.insert_many(data)  # data should be dictionary
        else:
            raise Exception ("Nothing to save, because data parameter is empty.")
        
# Create method to implement the R in CRUD.
    def read(self, data):
        # Checks to see if the data is null or empty and returns exception in either case
        if data is not None:
                return self.collection.find(data, {"_id":False})
        else:
            raise Exception("Nothing to search, because data parameter is empty.")
            
# The method to implement the U in CRUD.
    def update(self, data):
        if data is not None:
            return self.collection.update_many(data)
        else:
            raise Exception("Nothing to update, because data parameter is empty.")
            
# The method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            return self.collection.delete_many(data)
            
        else:
            raise Exception("Nothing to delete, because remove parameter is empty.")
